import React, { useEffect, useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { getMovies } from "../../../redux/actions"

function Row({ title, }) {
  const dispatch = useDispatch();
  const movies = useSelector(state => state.movies)
  const [state, setState] = useState()

  useEffect(() => {
    dispatch(getMovies())
  }, [dispatch]);

  useEffect(() => {
 
      let names = movies.map(d => d.genres)
      console.log(names)
    
}, []);



  

  return (
    <div className="conteiner__row">
      <h2>{title}</h2>
    </div>
  )
}

export default Row