import React, { useState } from 'react';
import { useDispatch, useSelector } from "react-redux";
import { useEffect } from 'react';
import { getimgrandom, getMovies } from "../../../redux/actions"
import "./banner.css";

function Banner() {

    const dispatch = useDispatch()
    const movies = useSelector((state) => state.movies)
    const [state, setState] = useState([]);

    useEffect(() => {
        dispatch(getMovies())
    }, [dispatch])


    console.log(movies)
    function truncate(string, n) {
        return string?.length > n ? string.substr(0, n - 1) + '...' : string;
    }
    const url = movies[Math.floor(Math.random() * movies.length)].medium_cover_image 

    return (
        <header className="banner__container" style={{
            backgroundPosition: "center center",
            backgroundSize: "cover",
            backgroundImage: `url(${url})` 
        }}>
            <div className="benner_content">
                <h1 className="banner__title">
                    Movie Name
                </h1>
                <div className="banner_buttons">
                    <button className='banner__button'>Play</button>
                    <button className='banner__button'>My List</button>
                </div>
                <h1 className="banner__description">
                    {truncate(`This is a text description This is a text description This is a text description This is a text description
                    This is a text descriptionThis is a text descriptionThis is a text descriptionThis is a text description
                    This is a text descriptionThis is a text descriptionThis is a text descriptionThis is a text descriptionThis is a text description
                    This is a text descriptionThis is a text descriptionThis is a text descriptionThis is a text descriptionThis is a text description
                    This is a text descriptionThis is a text descriptionThis is a text descriptionThis is a text description
                    This is a text descriptionThis is a text descriptionThis is a text descriptionThis is a text descriptionThis is a text descriptionThis is a text description
                    This is a text descriptionThis is a text descriptionThis is a text descriptionThis is a text description
                    This is a text descriptionThis is a text descriptionThis is a text description`
                        , 150)}
                </h1>
            </div>

            <div className="banner__fadeBottom" />
        </header>
    )
}

export default Banner